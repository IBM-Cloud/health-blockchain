

# Healthchain 

## Background

Review the [Hyperledger Composer documentation](https://hyperledger.github.io/composer/introduction/introduction.html) for background and concepts.

Composer only works on Linux and OSX operating systems.

## Local development instructions


### Install command line tools

```
$ npm install -g composer-cli
$ npm install -g composer-playground
$ npm install -g composer-rest-server
```

[Composer CLI reference](https://hyperledger.github.io/composer/reference/commands.html)

### Setup local fabric docker deployment

Read more about this on the [composer documentation page](https://hyperledger.github.io/composer/installing/development-tools.html).



Run the following script to install, configure, and boot local development environment:

`curl -sSL https://hyperledger.github.io/composer/install-hlfv1.sh | bash`

This will start the following services in docker:
- orderer
- CA
- peer
- couchdb
- composer playground

And will generate a `connection-profile` located at `~/.composer-connection-profile/hlfv1` called `hlfv1`.

The playground should launch at `localhost:8080`.


## Generate composer archive

The archive file compiles all the components of the composer application for distribution and deployment:

```
$ npm run prepublish
```

## Deploy composer archive

### Deploy to local fabric (using profile created by fabric-tools)
```
$ composer network deploy  -a fitchain-composer@0.0.1.bna -i admin -s adminpw -p hlfv1
```

### Deploy to playground

- Generate `/dist/fitchain.bna` using the `npm run prepublish` command
- Upload archive file to playground using the "Import/Replace" button.  *NOTE: a business network deployed by playground will have the network identifier of `org-acme-biznet` NOT `fitchain`*


### Run local REST server

`$ composer-rest-server`

### Deploy to remote fabric
Follow instructions here to deploy fabric on free tier k8s cluster on bluemix: [BETA K8s SCRIPTS](https://github.ibm.com/IBM-Blockchain/ibm-container-service)


Create a new connection profile in `~/.composer-connection-profiles/<PROFILE NAME>/connection.json`, configured to point to remote endpoints.
```
$ composer network deploy  -a dist/fitchain.bna -i <IDENTITY NAME> -s <IDENTITY SECRET> -p <PROFILE NAME>
```